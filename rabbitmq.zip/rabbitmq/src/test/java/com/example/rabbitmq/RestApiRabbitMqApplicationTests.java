package com.example.rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiRabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
