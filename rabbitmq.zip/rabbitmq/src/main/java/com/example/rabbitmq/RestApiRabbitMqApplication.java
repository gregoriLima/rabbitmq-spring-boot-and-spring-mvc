package com.example.rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiRabbitMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiRabbitMqApplication.class, args);
	}

}
